import React from 'react';

export default function Default() {
  return (
    <div>
      <h1>Books</h1>
    </div>
  );
}
