ALTER TABLE "books" ALTER COLUMN "search_text" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "books" ALTER COLUMN "search_text" DROP EXPRESSION;